$ErrorActionPreference='Stop'
$env:CARGO_HOME='C:/Git/NewDBMS/.tools/cargo'
$env:RUSTUP_HOME='C:/Git/NewDBMS/.tools/rustup'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$cargo='C:/Git/NewDBMS/.tools/cargo/bin/cargo.exe'
$results='C:/Git/NewDBMS/artifacts/backlog-validation'
New-Item -ItemType Directory -Path $results -Force | Out-Null
function Check([string]$name) {
    if ($LASTEXITCODE -ne 0) { throw "$name failed with exit $LASTEXITCODE" }
    Write-Output "$name passed"
}
& $cargo test --locked --features service,backlog-batch,benchmark-metrics,sync-stall -- --test-threads=1 *> "$results/rust.txt"
Check 'Rust safety tests'
& $cargo test --locked --features service,backlog-batch,benchmark-metrics,sync-stall,commit-window -- --test-threads=1 *> "$results/rust-window.txt"
Check 'Window feature safety tests'
& $cargo build --locked --features service,backlog-batch,benchmark-metrics,sync-stall --bin catdb-server *> "$results/build.txt"
Check 'Batch service build'
python benchmarks/backlog/test_protocol.py *> "$results/protocol.txt"
Check 'Independent batch service protocol'
python benchmarks/backlog/test_schedule.py *> "$results/schedule.txt"
Check 'Finite backlog scheduler'
python benchmarks/backlog/test_report.py *> "$results/report.txt"
Check 'Recovery and batch attribution'
$env:CATDB_EXPECT_METRICS='1'
python benchmarks/arrival-rate/test_metrics.py *> "$results/metrics.txt"
Check 'Counters and existing protocol'
Remove-Item Env:CATDB_EXPECT_METRICS
python benchmarks/arrival-rate/test_schedule.py *> "$results/previous-schedule.txt"
Check 'Existing scheduler'
python benchmarks/arrival-rate/test_report.py *> "$results/previous-report.txt"
Check 'Existing report'
& $cargo clippy --locked --features service,backlog-batch,benchmark-metrics,sync-stall --lib --bin catdb-server -- -D warnings *> "$results/clippy.txt"
Check 'Clippy'
& $cargo build --locked --release --features service,backlog-batch,benchmark-metrics,sync-stall --lib *> "$results/release.txt"
Check 'C ABI library build'
python -m unittest discover -s tests -p '*ffi_checks.py' *> "$results/ffi.txt"
Check 'C ABI'
& $cargo build --locked --features service,backlog-batch,benchmark-metrics,sync-stall,lock-timing --bin catdb-server *> "$results/diagnostic-build.txt"
Check 'Diagnostic combination build'
$env:CATDB_DIAGNOSTICS='pull'
python benchmarks/commit-tail/test_protocol.py *> "$results/pull.txt"
Check 'Pull protocol'
$env:CATDB_DIAGNOSTICS='1'
python benchmarks/commit-breakdown/test_diagnostics.py *> "$results/diagnostics.txt"
Check 'Legacy diagnostics'
Remove-Item Env:CATDB_DIAGNOSTICS
& $cargo build --locked --features service --bin catdb-server *> "$results/default-build.txt"
Check 'Default service build'
python benchmarks/arrival-rate/test_metrics.py *> "$results/default-protocol.txt"
Check 'Default API compatibility'
