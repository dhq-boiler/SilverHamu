$ErrorActionPreference='Stop'
$env:CARGO_HOME='C:/Git/NewDBMS/.tools/cargo'
$env:RUSTUP_HOME='C:/Git/NewDBMS/.tools/rustup'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$cargo='C:/Git/NewDBMS/.tools/cargo/bin/cargo.exe'
$out='C:/Git/NewDBMS/artifacts/backlog-tail-validation'
New-Item -ItemType Directory -Path $out -Force | Out-Null
function Check([string]$what) {
    if ($LASTEXITCODE -ne 0) { throw "$what failed: $LASTEXITCODE" }
    Write-Output "$what passed"
}
& $cargo test --locked --features service,backlog-batch,benchmark-metrics,sync-stall,lock-timing -- --test-threads=1 *> "$out/rust.txt"
Check 'Rust safety and bounded retention'
& $cargo build --locked --features service,backlog-batch,benchmark-metrics,sync-stall,lock-timing --bin catdb-server *> "$out/build.txt"
Check 'Profile service build'
python benchmarks/backlog-tail/test_protocol.py *> "$out/protocol.txt"
Check 'Buffered batch service'
python benchmarks/backlog-tail/test_analysis.py *> "$out/analysis.txt"
Check 'Exact timing attribution'
$env:CATDB_DIAGNOSTICS='pull'
python benchmarks/commit-tail/test_protocol.py *> "$out/pull.txt"
Check 'Existing pull protocol'
$env:CATDB_DIAGNOSTICS='1'
python benchmarks/commit-breakdown/test_diagnostics.py *> "$out/legacy.txt"
Check 'Existing streaming protocol'
Remove-Item Env:CATDB_DIAGNOSTICS
& $cargo clippy --locked --features service,backlog-batch,benchmark-metrics,sync-stall,lock-timing --lib --bin catdb-server -- -D warnings *> "$out/clippy.txt"
Check 'Clippy'
& $cargo build --release --locked --features service,backlog-batch,benchmark-metrics,sync-stall,lock-timing --lib *> "$out/release.txt"
Check 'Library build'
python -m unittest discover -s tests -p '*ffi_checks.py' *> "$out/ffi.txt"
Check 'C ABI'
& $cargo build --locked --features service --bin catdb-server *> "$out/default-build.txt"
Check 'Default service build'
python benchmarks/arrival-rate/test_metrics.py *> "$out/default-protocol.txt"
Check 'Default protocol'
